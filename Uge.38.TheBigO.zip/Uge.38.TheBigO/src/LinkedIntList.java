/**
 * Created by A.A on 9/26/2016.
 */
public class LinkedIntList {

    public ListNode front;
    private long steps;

    private class ListNode{
        public int data;
        public ListNode next ;

        public ListNode() {
            this(0,null);

        }
        public ListNode(int newData) {

            this(newData,null);
        }
        public ListNode(ListNode newNext){
            this(0,newNext);
        }

        public ListNode(int newData, ListNode newNext) {
            this.data=newData;
            this.next= newNext;
        }

    }

    public LinkedIntList() { //Constructs an empty list;
        this.front = null;
    }

    // returns the current number of elements in the list
    public int size() {
        int count = 0;
        long startTime = System.currentTimeMillis();
        ListNode current = front;
        while (current != null) {
            current = current.next;
            count++;
        }
        steps = System.currentTimeMillis() - startTime;
        return count;
    }

    //add value to the end of the list
    public void add(int value) {
        if (front == null) {
            front = new ListNode(value, front);
        } else {
            ListNode current = front;
            while (current.next != null) {
                current = current.next;
                steps++;
            }
            current.next = new ListNode(value, current.next);
        }
    }

    // print all elements in the list
    public void print() {
        ListNode current = front;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
            steps++;
        }
    }

    // returns comma-separated, version of the list
    public String toString() {

        long startTime = System.nanoTime();
        if (front == null) {
            return "[]";
        } else {
            String result = "[" + front.data;
            ListNode current = front.next;

            while (current != null) {
                result += ", " + current.data;
                current = current.next;
            }
            result += "]";
            long endTime = System.nanoTime();
            steps = endTime - startTime;
            return result;
        }

    }

    // return the time of Exection of method time in NanoSeconds
    public long getTime(){
        return steps;
    }

    //Builds a new LinkedList with specified number of nodes prev : n > 0
    public void BuildList(int n) {

        for (int i = n - 1; i >= 0; i--) {
            front = new ListNode(i, front);
            steps++;
        }
    }


}
