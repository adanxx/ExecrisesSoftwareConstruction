
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;
import sun.awt.image.ImageWatched;

import java.util.*;

public class RunProgram {
    public static void main(String[] args) {

        LinkedIntList list = new LinkedIntList();

        //testString(10,list);          //Execution time toString Method:
        //testString(100,list);
        //testString(1000,list);

        //testBuildNodes(10, list);     //Execution time of BuildList Method:
        //testBuildNodes(100, list);
        // testBuildNodes(1000,list);

        // testAdd(10, list);            //Execution time of AddNode Method
        // testAdd(100, list);
        // testAdd(1000,list);

        // testPrint(10, list);          //Execution time of Print Method;
        // testPrint(100,list);
        // testPrint(1000,list);

           testSize(10, list);            //Execution time of Size Method
           testSize(100,list);
           testSize(1000,list);
    }

     public static void testString( int value, LinkedIntList list ){

         int steps = 0;
         for(int i = 0 ; i < value; i++) {
             list.add(i);
             steps++;
         }
         System.out.println(list.toString());
         System.out.println("O(n) in toString completes in steps: "+steps);
         System.out.println("Execution time of toString with 10 input in NanoSeconds: "+list.getTime());
     }

     public static void testAdd(int value, LinkedIntList list){

         int steps = 0;
         for(int i = 0; i < 10 ; i++){
             list.add(value);
             steps++;
         }
         System.out.println("O(n)+O(value)");
         System.out.println("Execution time of "+value+" nodeAdd: "+list.getTime()+steps);

     }

     public static void testBuildNodes(int value, LinkedIntList list){

         list.BuildList(value);
         System.out.println("O(value)");
         System.out.println("Execution time of "+value+ " node: "+list.getTime()+" steps");

     }

     public static void testSize(int value, LinkedIntList list){

         for(int i = 0; i < value; i++){
             list.add(i);
         }
         System.out.println("Execution of time: "+list.getTime());

    }

     public static void testPrint(int value, LinkedIntList list){

         for(int i = 0; i < value ; i++){
            list.add(i);
         }
         System.out.println("O(n)");
         System.out.println("Execution time: "+list.getTime());

    }





}
