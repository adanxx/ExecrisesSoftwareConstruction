import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by A.A on 9/24/2016.
 */
public class genericLinkedListTest {
    ArrayList<Integer> list = new ArrayList<>();

    @Test (expected = IllegalArgumentException.class)
    public void testConstructor() throws Exception {
      ArrayList <Integer> negativelist = new ArrayList<>(-100);
    }
    @Test
    public void Size() throws Exception {
        list.add(1);
        list.add(2);

        assertEquals(2,list.size());

    }
    @Test
    public void Get() throws Exception {

        list.add(1);
        int num = list.get(0);

        assertEquals(1, num);
    }
    @Test
    public void ToString() throws Exception {

        list.add(1);
        list.add(2);

        String stringlist = list.toString();

        assertEquals(stringlist,list.toString());

    }
    @Test  // redundant to test add:
    public void testAdd() throws Exception {

    }
    @Test (expected = IndexOutOfBoundsException.class)
    public void testAdd2() throws Exception {
        list.add(1);
        list.add(2);

        list.add2(3,4);
    }
    @Test
    public void testIsEmpty() throws Exception {
        //if the list is empty return true;

       assertTrue(list.isEmpty());
    }
    @Test
    public void testClear() throws Exception {
        list.add(1);
        list.add(2);
        list.add(3);

        list.clear();

        assertEquals(0, list.size());

    }
    @Test
    public void indexOf() throws Exception {

        list.add(1);
        list.add(2);
        list.add(3);

        int number = list.indexOf(2);

        assertEquals(number, 1);


    }
    @Test (expected = IndexOutOfBoundsException.class)
    public void testRemove() throws Exception {

        list.remove(0); //tests the indexOutOfBound Exception

    }
    @Test
    public void testSet() throws Exception {

        list.add(1);
        list.add(2);
        list.add(2);

        list.set(2,3);

        int number = list.get(2);

        assertEquals(number, 3);

    }
    @Test
    public void testAddAll() throws Exception {
        list.add(1);
        list.add(2);
        list.add(3);

      ArrayList<Integer> list2 = new ArrayList<>();
        list2.add(4);
        list2.add(5);
        list2.add(6);

        list.addAll(list2);

        assertEquals(6, list.size());
    }
    @Test (expected = IndexOutOfBoundsException.class)
    public void testCheckIndex() throws Exception {

        list.get(-1);
    }

}