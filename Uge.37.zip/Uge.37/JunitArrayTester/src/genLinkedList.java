
public class genLinkedList {

    //Under Construction - 2020
}
