
/**
 * Created by A.A on 9/15/2016.
 */
public class student {

    private String name;
    private int age ;
    private int studeid;

    public student(String name, int age, int studeid) {
        this.name = name;
        this.age = age;
        this.studeid = studeid;
    }
    public student(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setStudeid(int studeid) {
        this.studeid = studeid;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getStudeid() {
        return studeid;
    }

    public String toString() {
        return "student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", studeid=" + studeid +
                '}';
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof student)) return false;

        student student = (student) o;

        if (age != student.age) return false;
        if (studeid != student.studeid) return false;
        return name.equals(student.name);

    }

}
