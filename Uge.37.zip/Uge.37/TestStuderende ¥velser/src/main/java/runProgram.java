/**
 * Created by A.A on 9/15/2016.
 */

import java.util.*;
public class runProgram {

    public static void main(String [] args) {


        student stud1 = new student("Abdi",26,1);
        student stud2 = new student("Ali",22,2);
        student stud3 = new student("Adan",22,3);
        student stud4 = new student("Adam",24,4);
        student stud5 = new student("Jama",25,5);

        System.out.println(stud1.toString());
        System.out.println(stud2.toString());
        System.out.println(stud3.toString());
        System.out.println(stud4.toString());
        System.out.println(stud5.toString());
        System.out.println();

        ArrayList<student> list = new ArrayList<student>();

        list.add(stud1);
        list.add(stud2);
        list.add(stud3);
        list.add(stud4);
        list.add(stud5);

        System.out.println("Output ArrayList student");
        for (student id : list){
            System.out.println(id);
        }

        String n1 = "hi";
        String n2 = "he";
        String n3 = "him";
        String n4 = "me";
        String n5 = "us";

    }

}
