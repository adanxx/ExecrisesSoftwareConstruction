import java.util.ArrayList;

/**
 * Created by A.A on 9/15/2016.
 */


public class TestArrayListClass extends ArrayList {

    private String element ;

    private String get(){
        return "";
    }
}
