/**
 * Created by A.A on 9/28/2016.
 */
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SharedCount {
    private static incrementCount indreAdd = new incrementCount();

    private static class runPro implements Runnable {
        public void run() {
            //synchronized (indreAdd){//implement synchronized block to prevent
            //                          race condition
                indreAdd.add();
           //}
        }
    }
        private static class incrementCount{
            private int count = 0;

            public int getCount() {
                return count;
            }

            public void add(){

                try {
                    for (int i = 0; i < 10; i++){
                        count++;
                        Thread.sleep(4);//increase value to see data-corruption
                    }
                   }catch (InterruptedException ex) {
                }
            }
        }

    public static void main(String[] args) {
        ExecutorService executor = Executors.newCachedThreadPool();

        //create and launch 10 threads
        for(int i = 0; i < 10 ; i++){
            executor.execute(new runPro());
        }
        executor.shutdown();
      while (!executor.isTerminated()){
      }
        System.out.println("count: "+indreAdd.getCount());
    }
}
