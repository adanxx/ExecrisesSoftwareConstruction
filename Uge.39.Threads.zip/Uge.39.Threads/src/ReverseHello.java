import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.*;

public class ReverseHello {

    private static int count = 0;

    static class reverseString implements Runnable {

        private String word;
        private static Lock lock = new ReentrantLock();

        public reverseString(String newWord){
           this.word = newWord;
        }
        public void run() {
            lock.lock();
            try {
                String text = "";
                for (int i = word.length(); i > 0; i--) {
                    char ch = word.charAt(i - 1);
                    text += ch;
                }
                    System.out.println(count+": "+text);
                    count++;
            } finally {
                lock.unlock();
            }
          }
    }

    public static void main(String[] args) throws InterruptedException {
        ExecutorService executor = Executors.newCachedThreadPool();

        for (int i = 0; i <= 50; i++) {
            executor.execute(new reverseString("Hello"));
        }
        executor.shutdown();
        while (!executor.isTerminated()) {
        }
    }
}