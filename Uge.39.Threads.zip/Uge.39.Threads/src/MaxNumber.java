/**
 * Created by A.A on 9/28/2016.
 */

import java.util.*;

public class MaxNumber {

    public static class SumThread extends Thread {
        private int min;
        private int max;
        private int[] arr;
        private int ans = 0;
        private int maxValue  = 0;

        public SumThread(int[] arr, int low, int high) {
            this.min = low;
            this.max = high;
            this.arr = arr;
        }

        public int getMaxValue(){
            return maxValue;
        }

        public void run() {
            int count = 0;
            for (int i = min; i < max; i++) {
                ans += arr[i];

                if(maxValue < arr[i]){
                    maxValue = arr[i];
                }
            }


        }

        public static void main(String[] args) throws InterruptedException {

            Random rand = new Random();
            int [] list = new int [100];

            for(int i =0 ; i < list.length; i++){
                list[i] = rand.nextInt(100)+1;
            }
             sum(list);

        }

     public static void sum(int [] list) throws InterruptedException {

         int Max = list.length;
         int maxSums = 0;
         int totalsums = 0;
         SumThread [] arrs = new SumThread[4];
         for (int i = 0 ; i < 4; i++){

             arrs[i] = new SumThread(list, (i*Max)/4,((i+1)*Max/4));
             arrs[i].start();

             System.out.print(i+" List: ");
             for(int j = ((i*Max)/4); j < (((i+1)*Max)/4); j++ ){
                 System.out.print(list[j]+" ");
             }
             System.out.println();
         }
         System.out.println();

          for (int i = 0; i < 4 ; i++ ){
              arrs[i].join();
              totalsums +=arrs[i].ans;
              if(maxSums <= arrs[i].ans){
                  maxSums = arrs[i].ans;

              }
              System.out.println(i+" MaxValue : "+arrs[i].maxValue);
          }
         System.out.println();
         System.out.println("sum: "+totalsums);


      }
    }
}