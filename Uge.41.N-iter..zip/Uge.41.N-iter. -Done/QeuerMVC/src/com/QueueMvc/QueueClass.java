package com.QueueMvc;

import java.util.*;

public class QueueClass {

    ListNode front;
    private int size;

    private class ListNode{

        private ListNode next;
        private int data;

        public ListNode( int newData, ListNode newNext) {
            this.data = newData;
            this.next = newNext;
        }
        public ListNode(int value){
            this.next = null;
            this.data = value;
        }
        public ListNode(){
            this.data = 0;
            this.next = null;
        }
    }

    public QueueClass(){
        front = null;
        size = 0;
    }

    public boolean isEmpty() {
        return front ==null;
    }

    public int getSize(){
        if(isEmpty()){
            throw new NoSuchElementException();
        }
        return size;
    }

    public void add(int value){

        if(isEmpty()) {
            front = new ListNode(value);
            size++;
        }else{
            ListNode current = front;
            while(current.next !=null) {
                current = current.next;
            }
            current.next = new ListNode(value);
            size++;
        }
    }

    public int peek(){
        if(isEmpty()){
            throw  new NoSuchElementException();
        }
        return front.data;
    }

    public String toString(){

        if(isEmpty()){
            return "[]";
        }
        String resulat ="["+front.data;
        ListNode current = front.next;
        while( current !=null){
            resulat += ", "+current.data;
            current = current.next;
        }
        resulat += "]";
        return resulat;
    }

}
