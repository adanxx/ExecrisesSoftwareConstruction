package com.QueueMvc;

import java.util.ArrayList;

public class dataUtil {


    public static ArrayList<QueueClass> getData(){

        //create an empty list:
        ArrayList<QueueClass> List = new ArrayList<>();

        //create Queue class :
         QueueClass newList = new QueueClass();

        //add data to the list
        for(int i = 0; i < 10; i++) {
            newList.add(i);
        }
        List.add(newList);

        //return the list
        return List;
    }



}
