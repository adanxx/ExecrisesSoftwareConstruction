package com.QueueMvc;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet(urlPatterns = "/Controller2")

public class ServletController1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      /*/request.getRequestDispatcher("/index.jsp").forward(request,response);/*/
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Step.0: get student from the helper class(model);
        ArrayList<QueueClass> stack = dataUtil.getData();

        //Step.1.: add the student to the request object:
        request.setAttribute("QUEUE_LIST",stack);

        //Step.2.: get request Dispatcher and forward the request to JSP
        request.getRequestDispatcher("/PresentationView.jsp").forward(request, response);

    }
}
