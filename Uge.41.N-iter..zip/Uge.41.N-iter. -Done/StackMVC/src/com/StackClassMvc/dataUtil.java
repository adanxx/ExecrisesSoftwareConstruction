package com.StackClassMvc;

import java.util.*;

public class dataUtil {


    public static ArrayList<StackClass> getData(){

        //create an empty list:
        ArrayList<StackClass> List = new ArrayList<>();

        //create stack class with size 10:
         StackClass newList = new StackClass(10);

        //add data to the stack list
        for(int i = 0; i < 10; i++) {
            newList.push(i);
        }
        List.add(newList);

        //return the list
        return List;
    }


}
