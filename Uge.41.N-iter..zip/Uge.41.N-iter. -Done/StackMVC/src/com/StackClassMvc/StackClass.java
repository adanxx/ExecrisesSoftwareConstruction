package com.StackClassMvc;

import java.util.*;

public class StackClass {

        private int []data;
        private int size =  -1;
        public static final int totalSize = 100;

        public StackClass(){
            this.data = new int [totalSize];
        }
        public StackClass(int capacity) {
            this.data = new int [capacity];
        }

        public void push( int value){

            if(isFully()){
                throw new ArrayIndexOutOfBoundsException("size:"+data.length);
            }else {
                size++;
                data[size] = value;

            }
        }

        public int pop(){

             int num ;
            if(isEmpty()) {
                return -1;
            }
            num = data[size];
            data[size--] = 0;
            return num;
        }

        public Boolean isEmpty(){
            return size < 0;
        }

        public int peek(){
            if(isEmpty()){
                throw new NoSuchElementException();
            }
            return data[size];
        }

        public boolean isFully(){
            return (size >= totalSize);
        }

        public int getSize(){
            return size+1;
        }

        public String toString(){

            if(isEmpty()){
                return "[]";
            }else{
                String result = "[" +data[0];
                for(int i = 1 ; i < getSize(); i++){
                    result += ", "+ data[i];
                }
                result +="]";
                return result;
            }

        }

    }
