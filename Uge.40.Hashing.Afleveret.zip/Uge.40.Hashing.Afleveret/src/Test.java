

public class Test {
    public static void main(String[] args) {

        HashIntSet list = new HashIntSet();

        System.out.println(list.getSize());

    }
}
