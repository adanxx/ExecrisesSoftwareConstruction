import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import javax.xml.bind.SchemaOutputResolver;

/**
 * Created by A.A on 10/17/2016.
 */
public class Exercise2 {
    public static void main(String[] args) {

        HashIntSet list = new HashIntSet(10);

        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

        System.out.println("1.String: "+list.toString());
        System.out.println("1.Array: "+list.toArray());
        System.out.println();

        HashIntSet list2 = new HashIntSet(10);

        list2.add(1);
        list2.add(2);
        list2.add(7);
        list2.add(4);

        //list2.add(44);
        System.out.println("2.String: "+list2.toString());
        System.out.println("2.Array: "+list2.toArray());
        System.out.println();


        System.out.println("containAll: "+list.containsAll(list2));
    }
}
