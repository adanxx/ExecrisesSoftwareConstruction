/**
 * Created by A.A on 10/17/2016.
 */
public class Exercise3 {
    public static void main(String[] args) {

        HashIntSet list = new HashIntSet();

        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

        HashIntSet list2 = new HashIntSet();

        list2.add(1);
        list2.add(2);
        list2.add(3);
        list2.add(4);
        //list2.add(5);

        System.out.println("Are Lists Equals: "+list.equals(list2));
        System.out.println("List1:"+list.toString());
        System.out.println("List2:"+list2.toString());

    }
}
