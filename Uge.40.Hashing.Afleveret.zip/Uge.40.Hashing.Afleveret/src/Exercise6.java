
public class Exercise6 {
    public static void main(String[] args) {

        HashIntSet list = new HashIntSet(12);
        for(int i = 0;  i < 10 ; i++ ){
            list.add(i);
        }
        System.out.println(list.toArray());
    }
}
