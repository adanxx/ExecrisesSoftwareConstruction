/**
 * Created by A.A on 10/17/2016.
 */
public class Exercise7 {

    public static void main(String[] args) {
        HashIntSet list = new HashIntSet(20); //creating an list with 20 empty slots
        for(int i = 0;  i < 10 ; i++ ){
            list.add(i);
        }
        System.out.println(list.toString());
    }
}
