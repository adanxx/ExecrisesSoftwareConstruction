import java.util.*;
import java.lang.*;


public class HashIntSet {

    private int[] elements;
    private int size;
    private static final int EMPTY = 0;
    private static final double MAX_LOAD = 0.75;
    private static final int REMOVED = -9999999; //special value used on remove

    //post: construct a new empty set of integers:
    public HashIntSet(){
        elements = new int [10];
        size = 0;
    }

    public HashIntSet(int value){
        elements = new int[value];
        size = 0;
    }

    //Returns the size of the elements in the set.
    public int getSize(){
        return size;
    }

    private int getIndex(int value) {
        if(value > elements.length){
            throw new IndexOutOfBoundsException();
        }else {

            for (int i = 0; i < elements.length; ++i) {
                if (elements[i] == value) {
                    return i;
                }
            }
            return -1;
        }
    }

    //Returns true if there are no elements in this set.
    public boolean isEmpty(){
        return size ==0;
    }

    // Returns the hash table's "load factor", its ratio of size to capacity.
    public double loadFactor() {
        return (double) size / elements.length;
    }

    // hash function for mapping values to indexes
    private int hash(int value) {
        return Math.abs(value) % elements.length;
    }

    // Resizes the hash table to twice its original capacity.
    private void rehash() {
        int[] newElements = new int[2 * elements.length];
        int[] old = elements;
        elements = newElements;
        size = 0;
        for (int n : old) {
            if (n != 0 && n != REMOVED) {
                add(n);
            }
        }
    }

    // Returns whether the given value is found in this set.
    public boolean contains(int value) {
        // linear probing to find proper index
        int h = hash(value);
        while (elements[h] != value) {
            h = (h + 1) % elements.length;
        }
        return elements[h] == value;
    }

    // Removes the given element value from this set,
    // if it was found in the set.
    public void remove(int value) {
        // linear probing to find proper index
        int h = hash(value);
        while (elements[h] != EMPTY && elements[h] != value) {
            h = (h + 1) % elements.length;
        }

        // remove the element
        if (elements[h] == value) {
            elements[h] = REMOVED;   // Displays -9999 to doc removed values in the set.
            size--;
        }
    }

    // Adds the given value to this set,
    // if it was not already contained in the set.
    public void add(int value) {
        // resize if necessary
        if (loadFactor() > MAX_LOAD) {
            rehash();
        }

        // linear probing to find proper index
        int h = hash(value);
        while (elements[h] != EMPTY && elements[h] != value && elements[h] != REMOVED) {
            h = (h + 1) % elements.length;
        }

        // add the element
        if (elements[h] != value) {
            elements[h] = value;
            size++;
        }
    }

    //Print the values in the list:
    public void print(){

        int count = 0;
        while(count < elements.length){

            if(elements[count] != 0){
                System.out.print(elements[count]+" ");
            }
            count++;
        }
    }

 //----------------------------------------Exercise--------------------------------------------------

   //Exercise.1.Done
    public void addAll(HashIntSet list) {

        int[] newElements = new int[elements.length + list.size];
        int[] old = elements;
        elements = newElements;
        size = 0;

        for (int n : old) {
            if (n != 0 && n != REMOVED) {
                add(n);
            }
        }
        int count = 0;
        while (count <= list.size) {
            if (list.getIndex(count) != 0 && list.getIndex(count) != REMOVED) {
                add(list.getIndex(count));

            }
            count++;
        }
    }

    //Exercise.2.Done
    public boolean containsAll(HashIntSet list){

        int num = 0;
        for(int i : elements) {
            if (i != 0 && i == list.getIndex(i)){
                    num++;
                }
        }
        return num == list.getSize();
    }

    //Exercise.3.Done
    public boolean equals(HashIntSet list){
        if( this.getSize() != list.getSize()){
            return false;
        }else {

            for(int i : elements) {
                if (i != 0 && i != list.getIndex(i)){
                    return false;
                }
            }
            return true;
        }
    }

    //Exercise.4.Done
    public void removeAll (HashIntSet list){

      Set<Integer> oldList = new HashSet<>();
        for(int i : elements){
                oldList.add(i);
        }
        for(int i : oldList){
            if( i == list.getIndex(i)){
                remove(i);               //All removed value are replaced with REMOVED=-99999 in the set.
                                         //!replace the REMOVE in remove method with = 0 to display the set
                                         // in clean form.
            }
        }
    }

    //Exercise.5.Done
    public void retainAll(HashIntSet list){

        Set<Integer> oldList = new HashSet<>();
        for(int i : elements){
            oldList.add(i);
        }
        for(int i : oldList){
            if( i != list.getIndex(i)){
                remove(i);               //All removed value are replaced with REMOVED=-99999 in the set.
                //!replace the REMOVE in remove method with = 0 to display the set
                // in clean form.
            }
        }

    }
    //Exercise.6.Done
    public String toArray() {
        return Arrays.toString(this.elements);
    }

    //Exercise.7.Done
    public String toString() {

        String result = "[ "+elements[0];

        for( int i = 1; i < elements.length; i++){

            if(elements[i] !=0) {
                result += "," + elements[i];
            }
        }
        result +="]";
        return result;
    }







}
