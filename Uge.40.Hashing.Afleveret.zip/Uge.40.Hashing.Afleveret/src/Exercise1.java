import java.util.*;

public class Exercise1 {
    public static void main(String[] args) {

        HashIntSet list = new HashIntSet(4);

        list.add(1);
        list.add(2);
        list.add(3);
        list.add(-5);

        System.out.println("list: "+list);
        System.out.println("list1Size: "+list.getSize());

        HashIntSet list2 = new HashIntSet(6);

        list2.add(2);
        list2.add(3);
        list2.add(6);
        list2.add(44);
        list2.add(79);

        System.out.println("list2: "+list2.toString());
        System.out.println("list2Size: "+list2.getSize());

        list.addAll(list2);
        System.out.println(list);
        System.out.println("newSize: "+list.getSize());


    }
}
