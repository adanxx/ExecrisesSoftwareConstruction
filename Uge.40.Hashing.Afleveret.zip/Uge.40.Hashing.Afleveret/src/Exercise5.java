/**
 * Created by A.A on 10/17/2016.
 */
public class Exercise5 {
    public static void main(String[] args) {
        HashIntSet list = new HashIntSet();

        list.add(-2);
        list.add(3);
        list.add(5);
        list.add(6);
        list.add(8);

        System.out.print("list: "+list.toString()+" ");
        System.out.println("size:"+list.getSize());


        HashIntSet list2 = new HashIntSet();

        list2.add(2);
        list2.add(3);
        list2.add(6);
        list2.add(8);
        list2.add(11);

        System.out.print("list2:"+ list2.toString()+" ");
        System.out.println("size:"+list2.getSize());
        System.out.println();
        list.retainAll(list2);
        System.out.println("After retainAll: "+list);
    }
}
