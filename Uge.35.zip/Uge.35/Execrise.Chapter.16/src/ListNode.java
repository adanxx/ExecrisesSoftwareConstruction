/**
 * Created by A.A on 9/9/2016.
 */
public class ListNode extends LinkedIntList{

    public int data;
    public ListNode next ;

    public ListNode() {
        this(0,null);

    }
    public ListNode(int newData) {

        this(newData,null);
    }
    public ListNode(ListNode newNext){
        this(0,newNext);
    }

    public ListNode(int newData, ListNode newNext) {
        this.data=newData;
        this.next= newNext;
    }
}
