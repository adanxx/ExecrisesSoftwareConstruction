/**
 * Created by A.A on 9/8/2016.
 */
import sun.awt.image.ImageWatched;

import javax.xml.bind.SchemaOutputResolver;
import java.util.*;
import java.lang.*;
public class runProgram {
    public static void main(String[] args) {

        /*/
        LinkedIntList list = new LinkedIntList();

        list.add(1);
        list.add(2);
        System.out.println(list.size());
        System.out.println(list.get(0));
        list2.addToGivenIndex(3,2);
        list.print();
       /*/
        //-------------------------------------------Exercises----------------------------------------------

        /*/Exercises.1.Done:---------------------------------------------------------------------------------
        LinkedIntList list2 = new LinkedIntList();

        list2.add(1);
        list2.add(2);
        list2.add(3);
        list2.add(4);

        list2.set(0,3); //replace the index of the given value with new value
        list2.print();
        System.out.println();
        /*/
        /*/Exercises.2.Done----------------------------------------------------------------------------------
        //System.out.println("Return Max Number: "+list2.getMax());
        /*/
        /*/Exercises.3.Done---------------------------------------------------------------------------------
        System.out.println("Is List2 sorted: "+list2.isSorted()); //checks if the list is sorted
        /*/
        /*/Exercises.4.Done----------------------------------------------------------------------------------
        LinkedIntList list3 = new LinkedIntList();
        list3.add(1);
        list3.add(18);
        list3.add(2);
        list3.add(7);
        list3.add(18);
        list3.add(39);
        list3.add(18);
        list3.add(40);

        System.out.println(list3.lastIndexOf(3)); // return -1 , value is not found in the list
        System.out.println(list3.lastIndexOf(18)); // return the last occurrence index of the value
        /*/
        /*/Exercises.5.Done---------------------------------------------------------------------------------
        LinkedIntList list4 = new LinkedIntList();

        list4.add(1);
        list4.add(1);
        list4.add(1);
        list4.add(3);
        list4.add(3);
        list4.add(6);
        list4.add(9);
        list4.add(15);
        list4.add(15);
        list4.add(23);
        list4.add(23);
        list4.add(23);
        list4.add(40);
        list4.add(40);

        System.out.println(list4.countDuplicates()); // count the number of duplicates.
        /*/
        /*/ Exercises.6.Done----------------------------------------------------------------------
        LinkedIntList list5 = new LinkedIntList();

        list5.add(1);
        list5.add(18);
        list5.add(2);
        list5.add(7);
        list5.add(8);
        list5.add(39);
        list5.add(18);
        list5.add(40);
        System.out.println(list5.hasTwoConsecutive());
        /*/
        /*/ Exercises.7.Done-------------------------------------------------------------------------------

        LinkedIntList list6 = new LinkedIntList();

        list6.add(1);
        list6.add(18);
        list6.add(2);
        list6.add(7);
        list6.add(8);
        list6.add(39);
        list6.add(18);
        list6.add(40);

        list6.print();
        System.out.println();
        System.out.println("The deletedBack Value in the list: "+list6.deleteBack());
        list6.print();
        /*/
        /*/ Exercises.8.Done-------------------------------------------------------------------------
          LinkedIntList list7 = new LinkedIntList();

        list7.add(1);
        list7.add(8);
        list7.add(19);
        list7.add(4);
        list7.add(17);

        list7.print();
        System.out.println();
        list7.swithPairs();
        list7.print();
        /*/
        /*/ Exercises.9.Done-------------------------------------------------------------------

        LinkedIntList list8 = new LinkedIntList();

        list8.add(1);
        list8.add(8);
        list8.add(19);
        list8.add(4);
        list8.add(17);

        list8.print();
        System.out.println();
        list8.stutter();
        list8.print();
        /*/
        /*/ Exercises.10.Done-----------------------------------------------------------------

        LinkedIntList list9 = new LinkedIntList();

        list9.add(1);
        list9.add(8);
        list9.add(19);
        list9.add(4);
        list9.add(17);

        list9.print();
        System.out.println();
        list9.stretch(1);
        list9.print();
        /*/
        /*/ Exercises.11.Done-----------------------------------------------------------------
         LinkedIntList list10 = new LinkedIntList();

         list10.add(1);
         list10.add(8);
         list10.add(19);
         list10.add(4);
         list10.add(17);
        //list10.add(10);  //test see the output with odd or Even list elements

        list10.print();
        System.out.println();
        list10.compress();
        list10.print();
        /*/
        /*/ Exercises.12.Not Done-------------------------------------------------------------------
        LinkedIntList list11 = new LinkedIntList();
        list11.add(8);
        list11.add(7);
        list11.add(-4);
        list11.add(19);
        list11.add(0);
        list11.add(43);
        list11.add(-8);
        list11.add(-7);
        list11.add(2);
        list11.print();
        System.out.println();

        list11.split();
        list11.print();
        /*/
        /*/ Exercises.13.Done-----------------------------------------------------------------------
        LinkedIntList list12 = new LinkedIntList();
        list12.add(8);
        list12.add(17);
        list12.add(2);
        list12.add(4);

        LinkedIntList list13 = new LinkedIntList();
        list13.add(1);
        list13.add(2);
        list13.add(3);

        list12.transferForm(list13);
        System.out.println("After the transfer:");
        list12.print();
        System.out.println("\nSecond List: "+list13.toString());
        /*/
        /*/ Exercises.14.Done--------------------------------------------------------------------
        LinkedIntList list12 = new LinkedIntList();
        list12.add(3);
        list12.add(9);
        list12.add(4);
        list12.add(2);
        list12.add(3);
        list12.add(8);
        list12.add(17);
        list12.add(4);
        list12.add(3);
        list12.add(18);
        list12.print();
        System.out.println();
        list12.removeAll(3);
        list12.print();
        /*/
        /*/ Exercises.15.Done------------------------------------------------------------------------
        LinkedIntList temp = new LinkedIntList();

        LinkedIntList list15 = new LinkedIntList();
        list15.add(1);
        list15.add(2);     //Change the value of the elements to test if the inner value state:
        list15.add(3);
        //list15.add(4);

        LinkedIntList list16 = new LinkedIntList();
        list16.add(1);
        list16.add(2);
        list16.add(3);
        System.out.println("Not Equals: "+list15.notEquals(list16));
        /*/
        /*/Exercises.16.Not Done------------------------------------------------------------------------
         LinkedIntList list17 = new LinkedIntList();
         LinkedIntList list18 = new LinkedIntList();
        /*/
        /*/Exercises.17.Done------------------------------------------------------------------------
        LinkedIntList  list19 = new LinkedIntList();
        list19.add(8);
        list19.add(13);
        list19.add(4);
        list19.add(2);
        list19.add(3);
        list19.add(8);
        list19.add(17);
        list19.add(4);
        list19.add(3);
        list19.add(18);
        list19.print();
        System.out.println();
        list19.removeRange(1,4);
        list19.print();
       /*/
        /*/Exercises.18.Done------------------------------------------------------------------------
        LinkedIntList list20 = new LinkedIntList();
        list20.add(1);
        list20.add(2);
        list20.add(3);
        list20.add(4);
        list20.print();
        System.out.println();

        list20.doubleList();
        list20.print();
        /*/
        /*/Exercises.19.Done------------------------------------------------------------------------

        LinkedIntList list20 = new LinkedIntList();
        list20.add(1);
        list20.add(2);
        list20.add(3);
        list20.add(4);
        list20.print();
        System.out.println();
        list20.rotate();
        list20.print();
        /*/
        //Exercises.20.Not Done------------------------------------------------------------------------
        LinkedIntList list21 = new LinkedIntList();
        list21.add(10);
        list21.add(31);
        list21.add(42);
        list21.add(23);
        list21.add(44);
        list21.add(75);
        list21.add(86);
        list21.print();
        System.out.println();
        list21.shift();
        list21.print();

        //Exercises.21.Not Done------------------------------------------------------------------------


    }
}
