import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * Created by A.A on 9/8/2016.
 */

public class LinkedIntList {

    private ListNode front; // first value in the list

    public LinkedIntList() { //Constructs an empty list;
        this.front = null;
    }

    public void clear() {
        front = null;
    }

    // returns the integer at given index
    public int get(int index) {
        return nodeAt(index).data;
    }

    // returns the current number of elements in the list
    public int size() {
        int count = 0;
        ListNode current = front;
        while (current != null) {
            current = current.next;
            count++;
        }
        return count;
    }

    public int InsideSize() {
        int count = 0;
        ListNode current = front;
        while (current != null) {
            current = current.next;
            count++;
        }
        return count;
    }

    //add value to the end of the list
    public void add(int value) {
        if (front == null) {
            front = new ListNode(value, front);
        } else {
            ListNode current = front;
            while (current.next != null) {
                current = current.next;
            }
            current.next = new ListNode(value, current.next);
        }
    }

    // removes value from at given index
    public void remove(int index) {
        if (index == 0) {
            front = front.next;
        } else {
            ListNode current = nodeAt(index - 1);
            current.next = current.next.next;
        }
    }

    // print all elements in the list
    public void print() {
        ListNode current = front;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
    }

    // return a reference to node at given index
    public ListNode nodeAt(int index) {
        ListNode current = front;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current;
    }

    // returns comma-separated, version of the list
    public String toString() {

        if (front == null) {
            return "[]";
        } else {
            String result = "[" + front.data;
            ListNode current = front.next;

            while (current != null) {
                result += ", " + current.data;
                current = current.next;
            }
            result += "]";
            return result;
        }
    }

    // Inserts the given value at the given index
    public void addToGivenIndex(int value, int index) {
        if (index == 0) {
            front = new ListNode(value, front);
        } else {
            ListNode current = nodeAt(index - 1);
            current.next = new ListNode(value, current.next);
        }
    }

    //Builds a new LinkedList with specified number of nodes.
    // prev : n > 0
    public void LinkedIntList(int n) {
        for (int i = n - 1; i >= 0; i--) {
            front = new ListNode(i, front);
        }
    }

//----------------------------------------Exercises Method-------------------------------------------------------------
    //Exercises.1.Done
    public void set(int value, int index) {
        if (index == 0) {
            front = new ListNode(value);
        } else {
            ListNode current = nodeAt(index - 1);

            current.next = new ListNode(value);
        }
    }

    //Exercises.2.Done
    public int getMax() {
        int Max = 0;
        if (front == null) {
            return -1;
        } else {
            ListNode current = front;
            while (current != null) {
                if (current.data > Max) {
                    Max = current.data;
                }
                current = current.next;
            }
            return Max;
        }
    }

    //Exercises.3.Done
    public boolean isSorted() {

        int count = 0;
        int Max = front.data;
        if (front == null) {
            return true;
        } else {
            ListNode current = front;
            while (current.next != null) {

                if (current.data >= Max) {
                    Max = current.data;
                } else {
                    return false;
                }
                current = current.next;
            }
        }
        return true;
    }

    //Exercises.4.Done
    public int lastIndexOf(int value) {
        int index = 0;
        int count = 0;
        ListNode current = front;
        while (current != null) {
            if (current.data == value) {
                index = count;
            }
            count++;
            current = current.next;
        }
        if (index == 0) {
            return -1;
        }
        return index;
    }

    //Exercises.5.Done
    public int countDuplicates() {

        int count = 0;
        int value = 0;
        if (front == null) {
            return -1;
        } else {
            value = front.data;
            ListNode current = front;
            while (current.next != null) {
                if (current.data == value) {
                    count++;
                } else {
                    value = current.data;
                }
                current = current.next;
            }
        }
        return count;
    }

    //Exercises.6.Done
    public boolean hasTwoConsecutive() {

        if (front == null) {
            return false;
        } else {
            int prev = front.data; //first value of front
            ListNode current = front.next; // next value after front

            while (current.next != null) {
                if (prev - current.data == -1) {
                    return true;
                }
                prev = current.data;
                current = current.next;
            }
        }
        return false;
    }

    //Exercises.7.Done
    public int deleteBack() throws NoSuchElementException {
        int last = 0;
        if (front == null) {
            throw new NoSuchElementException();
        } else {
            ListNode current = front;
            while (current.next.next != null) {
                current = current.next;

            }
            last = current.next.data;
            current.next = current.next.next;

        }
        return last;
    }

    //Exercises.8.Done
    public void swithPairs() throws NoSuchElementException {

        ListNode prev = front;
        if (front != null && front.next != null) {
            ListNode current = front;
            front = front.next;
            current.next = front.next;
            front.next = current;
            prev = current;


            while (prev != null && prev.next != null && prev.next.next != null) {

                ListNode first = prev.next;
                ListNode second = first.next;
                first.next = second.next;
                second.next = first;
                prev.next = second;
                prev = first;
            }

        } else {
            throw new NoSuchElementException();

        }
    }

    //Exercises.9.Done
    public void stutter() throws NoSuchElementException {

        ListNode prev = front;
        if (front != null && front.next != null) {

            ListNode current = new ListNode(front.data, front.next); // point new Node with value at next
            front.next = current;  // connects front with current
            prev = current; // prev is point at current value

            while (prev != null && prev.next != null) {
                ListNode first = prev.next;
                ListNode second = first.next;
                first.next = new ListNode(first.data, second);
                prev = first.next; // point at the new number to be duplicated

            }

        } else {
            throw new NoSuchElementException();
        }
    }

    //Exercises.10.Done
    public void stretch(int n) throws NoSuchElementException {

        ListNode prev = front;
        if (n == 0) {
            //front = new ListNode(null);
            System.out.println("[]");
        } else if (n > 0) {

            ListNode current = front.next; // point at front.next Node
            //ListNode Node = new ListNode(front.data,current); // a new node Point current
            //prev.next = Node; // connects the first Node with new add Node
            //prev = Node; // point at the new Node

            while (prev != null && current != null) {

                int count = 0;
                while (count < n) {

                    ListNode temp = new ListNode(prev.data, current);
                    prev.next = temp;
                    prev = temp;
                    count++;
                }
                current = current.next;
                prev = prev.next;
            }
            int num = 0;
            while (num < n) {

                prev.next = new ListNode(prev.data);
                prev = prev.next;
                num++;
            }
        } else {
            throw new NoSuchElementException();
        }
    }

    //Exercises.11.Done
    public void compress() {

        if (front == null) {
            //front = new ListNode(null);
            System.out.println("[]");
        } else {

            ListNode prev = front;
            ListNode current = prev.next;
            ListNode temp = new ListNode(prev.data + current.data, current.next);
            front = temp;
            prev = front;

            while (prev.next != null && prev.next.next != null) {

                ListNode first = prev.next;
                ListNode second = first.next;

                ListNode temp1 = new ListNode((first.data + second.data), second.next);
                prev.next = temp1;
                prev = temp1;


            }
        }
    }

    //Exercises.12.Not Done
    public void split() throws NoSuchElementException {

       if(front == null){
           throw new NoSuchElementException();
       }else{

           front = new ListNode(0, front); // DummyNode;

           ListNode prev = front;
           ListNode center = prev.next;
           ListNode tail= center.next;

           do{

               System.out.print(center.data+" ");

           /*/
               if(prev.next.data < 0){
                     prev = center.next;
                     center.next = front;
                     front.next = center;

                   center = tail;
                   tail =tail.next;

               }else {

                   prev = prev.next;
                   center = center.next;
                   tail = tail.next;
               }
         /*/
           }while(tail!=null);

       }

    }

    //Exercises.13.Done
    public void transferForm(LinkedIntList list) {

        ListNode prev = front;
        int count = 0;

        while (count < list.size()) {

            while (prev.next != null) {
                prev = prev.next;
            }
            prev.next = new ListNode(list.nodeAt(count).data, prev.next);
            count++;
        }

        list.clear();  // using the clear method the empty the second list.
    }

    //Exercises.14.Done
    public void removeAll(int n) {
        if (front == null) {
            System.out.println("[]");
        } else {
            if(front.data == n){
                front=front.next;
            }
            ListNode current = front;

            while (current.next != null) {

                if(current.next.data == n) {
                    current.next = current.next.next;
                }else{
                    current=current.next;
                }
            }
        }
    }

    //Exercises.15.Done
    public boolean notEquals(LinkedIntList list2) {

        int count = 0;
        for (ListNode current = front; current != null; current = current.next) {
            count++;
        }
        if(!(count == list2.size())){ // checks and compares the lists size and return:
            return true;
        }else{
            int num = 0;
            ListNode current = front;
            while( current !=null){
                if(current.data != list2.nodeAt(num).data){
                    return true;
                }else {
                    current = current.next;
                    num++;
                }
            }
        }
       return false;
    }

    //Exercises.16.Not Done
    public void removeEven(){

    }

    //Exercises.17.Done
    public void removeRange(int first, int last)throws NoSuchElementException, IndexOutOfBoundsException{


        if(front ==null || first < 0 || last < 0){
            throw new  NoSuchElementException();
        }else if( 0 <= first && first <= last && last < front.size()){

            ListNode prev = nodeAt(first-1);
            ListNode current = nodeAt(last+1);

           prev.next = current;
        }else{
            throw new IndexOutOfBoundsException();
        }

    }

    //Exercises.18.Done
    public void doubleList(){

        int size = size();  //size of the list;

        ListNode prev = front;
        ListNode current = front.next;

        int count = 0;
        while(count != size){

            while(current.next !=null){
                current = current.next;
            }
            current.next = new ListNode(prev.data);
            prev = prev.next;
            count++;
        }
    }

    //Exercises.19.Done
    public void rotate(){

        if(front ==null || size() <= 1){
            System.out.println("Number of data in the list"+size());
        }else{

            ListNode prev = front;
            ListNode current = front.next;

            while (current.next !=null){
                current=current.next;
            }
                front = front.next;
                prev.next = null;
                current.next = prev;
                prev = front;
                current=current.next;

        }

    }

    //Exercises.20.Not Done
    public void shift() throws NoSuchElementException{

        if(front==null){
            throw new NoSuchElementException();
        }else{

            front = new ListNode(0, front); // Dummy Node;

            ListNode prev = front;
            ListNode current= front.next; // Point at first data:
            ListNode tail = current.next;

            while(tail.next !=null){ // point the tell node at end of the list:
                tail = tail.next;
            }

            if(current.data > 0){

                prev.next = current.next;
                tail.next = current;
                current.next = null;
                current = prev.next;
                tail = tail.next;

            }else{
                prev=prev.next;
                current = current.next;

            }
            System.out.println("prev: "+prev.data+" current: "+current.data+" tail: "+tail.data);


        }


    }
    //Exercises.21.Not Done
    public void reverse(){
    }


}


