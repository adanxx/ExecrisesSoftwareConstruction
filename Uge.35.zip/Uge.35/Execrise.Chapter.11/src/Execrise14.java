/**
 * Created by A.A on 8/30/2016.
 */
import java.util.*;
public class Execrise14 {


    public static void main(String[] args) {

        Map<String, Integer> list1 = new HashMap<String, Integer>();

        list1.put("Logan",62);
        list1.put("Janet",87);
        list1.put("Kim",52);
        list1.put("Whitaker",52);
        list1.put("Stefanie",80);
        list1.put("Jeff",88);
        list1.put("Sylvia",95);

        Map<String, Integer> list2 = new HashMap<String, Integer>();

        list2.put("Jeff",88);
        list2.put("Lisa",83);
        list2.put("Sylvia", 95);
        list2.put("Brain",90);
        list2.put("Kim",52);

     Map<String, Integer> list3 = new HashMap<String, Integer>();

        for( String name : list1.keySet()){

            if(list2.containsKey(name) ){

                int number = list2.get(name);

                if(list2.containsValue(number)){

                    list3.put(name,number);
                }
            }
        }

        System.out.println(list3);
    }

}
