import java.util.Map;
import java.util.*;
/**
 * Created by A.A on 8/31/2016.
 */
public class Execrise18 {
    public static void main(String[] args) {

        Map<Integer,String > list = new HashMap<Integer,String>() ;

        list.put(42,"Dave");
        list.put(13,"Ed");
        list.put(3,"maria");
        list.put(81,"Sue");
        list.put(17,"Ed");
        list.put(56,"maria");
        list.put(23,"Ed");

        System.out.println("OldList: "+list);
        System.out.println();

        reverseList(list);
    }

    public static void reverseList(Map<Integer,String>file){

        Map<String, String> reverseList = new HashMap<String, String>();

        // System.out.println("All The Key: "+listKeys);
        // System.out.println();

        List<Integer> ListValues = new LinkedList<Integer>();

        for( int n : file.keySet()){
            ListValues.add(n);
        }

        Iterator<Integer> Iter = ListValues.iterator();

        while(Iter.hasNext()) {// add  the reverse list into a new Map list

            int number = Iter.next();  //Takes the number in LinkedList
            String name = file.get(number); //find the values parred with the number

            if (reverseList.containsKey(name)) {  //is the name seen before

                String OldNumber = reverseList.get(name)+","+number; //add the new number with the old

                reverseList.put(name, OldNumber);

            } else   // if never seen before

                reverseList.put(name, "["+number+"");
         }

        for(String last : reverseList.keySet()){

            String fin = reverseList.get(last)+"]"; //add the new number with the old
            reverseList.put(last,fin);
        }

        System.out.println("ReverseList: "+reverseList);
    }
}
