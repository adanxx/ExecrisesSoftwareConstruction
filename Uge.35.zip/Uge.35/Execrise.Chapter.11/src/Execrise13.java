import java.util.Map;

/**
 * Created by A.A on 8/30/2016.
 */
import java.util.*;
public class Execrise13 {

    public static void main(String[] args) {


        Map<String, String> names = new TreeMap<String, String>();

        names.put("Marty","Stepp");        // add to test the programs boolean by adding same values or not
        names.put("Stuart","Reges");       // to the Map. The Current setting is false
        names.put("Jessica","Miller");
        names.put("Amanda","Camp");
        names.put("Hal","Perkins");
        names.put("John","UNKNONW");         //Change the value here


        Map<String, Integer> countNames = new TreeMap<String, Integer>(); // a new list to add efternames

        Boolean state = false;

        Collection<String> eftername = names.values();

        for(String num : eftername){

            if(countNames.containsKey(num)){  // test if list contains the same word

                int i = countNames.get(num);
                countNames.put(num, i+1);

            }else{ // eftername is add if not found

                countNames.put(num, 1);
            }
        }
        Collection<Integer> newCount = countNames.values();

        for(int n: newCount){

            if(n >= 2){

                state = true;

            }
        }

        System.out.println("Does Map Contain Keys with same Value: "+state);

    }

}
