import java.util.LinkedList;
import java.util.*;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise7 {

    public static void main(String[] args) {

        List<Integer> list1 = new LinkedList<Integer>();

        list1.add(3);
        list1.add(7);
        list1.add(3);
        list1.add(-1);
        list1.add(2);
        list1.add(3);
        list1.add(7);
        list1.add(2);
        list1.add(15);
        list1.add(15);

      Set<Integer> list11 = new TreeSet<Integer>();

        for (int n : list1){
            list11.add(n);
        }


        List<Integer> list2 = new LinkedList<Integer>();

        list2.add(-5);
        list2.add(15);
        list2.add(2);
        list2.add(-1);
        list2.add(7);
        list2.add(15);
        list2.add(36);

        Set<Integer> list22 = new TreeSet<Integer>();

        for (int n : list2){
            list22.add(n);
        }

        System.out.println("List1: "+list1);
        System.out.println("List2: "+list2);
        System.out.println();

        int count = countCommen(list11,list22);

        System.out.println("The List contains: "+count+ " number that occur in  both list");

    }

    public static int countCommen(Set<Integer>list1, Set<Integer>list2){

        Set<Integer> num = new HashSet<Integer>(list1);
        num.retainAll(list2);
        return num.size();
    }

}
