import java.util.*;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise8 {

    public static void main(String[] args) {

        List<String> list = new LinkedList<String>();

        list.add("Hellow");
        list.add("Muse");
        list.add("babalion");
        list.add("Copenhagen");
        list.add("Paris");

        for(String n : list){
            System.out.println(n);
        }

        String word = shortString(list);

        System.out.println("The Short word in the list is: "+word);

    }
    public static String shortString(List<String> list){

        if (list.isEmpty()){
           return null;
        }

            Iterator<String> i = list.iterator();

            String word = i.next();

            while (i.hasNext()) {

                String next = i.next();
                if (next.length() < word.length()) {

                    word = next;
                }
            }
      return word;
    }


}
