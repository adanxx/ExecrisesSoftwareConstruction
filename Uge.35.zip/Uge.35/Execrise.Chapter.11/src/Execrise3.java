import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.*;
import java.lang.*;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise3 {

    public static void main(String[] args) {

        List<Integer> list1 = new LinkedList<Integer>();

        list1.add(1);
        list1.add(1);
        list1.add(2);
        list1.add(0);
        list1.add(4);
        list1.add(5);
        list1.add(6);
        list1.add(8);
        list1.add(8);
        list1.add(3);
        list1.add(11);
        list1.add(9);
        list1.add(0);
        list1.add(14);
        list1.add(0);
        list1.add(16);

            System.out.println("Size of list: "+list1.size());
            System.out.println("List: "+list1);

        int max = 13;
        int min = 5;

        Iterator<Integer> num = list1.iterator();

        while(num.hasNext()){

            int i = num.next();

            if(i % 2 == 0 && i > min && i < max  ){

                num.remove();
            }
        }
        System.out.println(list1);

    }
}
