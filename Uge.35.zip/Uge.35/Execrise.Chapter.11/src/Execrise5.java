import java.util.LinkedList;
import java.util.List;
import java.util.*;

import static java.util.Collections.*;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise5 {

    public static void main(String[] args) {

        List<Integer> list1 = new LinkedList<Integer>();

        list1.add(7);
        list1.add(4);
        list1.add(-9);
        list1.add(4);
        list1.add(18);
        list1.add(8);
        list1.add(15);
        list1.add(27);
        list1.add(7);
        list1.add(11);
        list1.add(-5);
        list1.add(32);
        list1.add(-9);
        list1.add(-9);

        System.out.println("Old List"+list1);
        System.out.println();

        sortAndRemoveDuplicates(list1);

    }

    public static void sortAndRemoveDuplicates(List<Integer> list2){

        Set<Integer> newList = new HashSet<Integer>();

        for(int n : list2){

           newList.add(n);
        }

        System.out.println("New List:"+ newList);
    }

}
