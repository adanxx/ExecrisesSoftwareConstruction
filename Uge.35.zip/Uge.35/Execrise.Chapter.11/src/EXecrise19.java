import sun.applet.resources.MsgAppletViewer_sv;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.*;

/**
 * Created by A.A on 8/31/2016.
 */
public class EXecrise19 {

    public static void main(String[] args) {


        Map<String, Integer> rarest = new TreeMap<String,Integer>();

        rarest.put("one", 1);
        rarest.put("two", 2);
        rarest.put("three", 3);
        rarest.put("threeone", 3);
        rarest.put("twoone", 2);
        rarest.put("threetwo", 3);
        rarest.put("four", 4);
        rarest.put("five", 5);

        getRarestNumber(rarest);
    }

   public static void getRarestNumber(Map<String,Integer> list) {

       Map<Integer,Integer> newList = new TreeMap<Integer,Integer>();

       List<Integer> allValues = new LinkedList<>(list.values());

       Iterator <Integer> Iter = allValues.iterator();


       while(Iter.hasNext()) {

           int number = Iter.next();
           System.out.print(number +" ");
       }
   }
}
