import java.util.*;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise10 {

    public static void main(String[] args) {

        List<Integer> list1 = new LinkedList<Integer>();

        list1.add(2);
        list1.add(3);
        list1.add(5);
        list1.add(10);
        list1.add(7);
        list1.add(13);
        list1.add(36);

        System.out.println("Old List: "+list1);
        System.out.println();

        removeOdd(list1);
    }

    public static void removeOdd(List<Integer>list){

        Iterator<Integer> i = list.iterator();

        int count = 0;

        while(i.hasNext()){

            int number = i.next();

            if(number % 2 !=0){
                i.remove();
                count++;
            }
        }
        System.out.println("New List: "+list);
        System.out.println(count+" : odd number were removed from the list");
    }

}
