import java.util.*;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise15 {

    public static final int NUMBERS = 10;


    public static void main(String[] args) {


        //Set<Integer> InputNumber = getNumbers(); // not working, system wont let user input.

        List<Integer> TotalNum = new LinkedList<Integer>();

        TotalNum.add(1);
        TotalNum.add(2);
        TotalNum.add(3);
        TotalNum.add(2);
        TotalNum.add(3);
        TotalNum.add(4);
        TotalNum.add(5);
        TotalNum.add(2);

        Map<Integer,Integer> countList = new HashMap<Integer,Integer>();

        if(TotalNum.isEmpty()){

            System.out.println(" The list Contains: " +TotalNum.size());
        }

        for( int number : TotalNum) {

            if (countList.containsKey(number)) {    // word is seen before

                int count = countList.get(number);
                countList.put(number, count + 1);   // the word value is increment ++
            }else {  // list does not contain the word it is add
                countList.put(number, 1);
            }
        }

        for(int i : countList.keySet()){

            int allnum = countList.get(i);

            System.out.println(i + " occurs "+ allnum+ " times");

        }
    }

    public static Set<Integer> getNumbers(){

        Set<Integer> listOfNum = new TreeSet<Integer>();

        Scanner input = new Scanner(System.in);

        System.out.print("Type in "+NUMBERS+" number: ");

        while(listOfNum.size() > NUMBERS){
            int num = input.nextInt();
            listOfNum.add(num);
        }
        return listOfNum;
    }
}
