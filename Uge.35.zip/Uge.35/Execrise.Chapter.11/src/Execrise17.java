/**
 * Created by A.A on 8/30/2016.
 */
import java.util.*;
public class Execrise17 {
    public static void main(String[] args) {

        Map<String, String> superMap = new TreeMap<String, String>();

        superMap.put("marty", "206-9024");
        superMap.put("hawking", "123-4567");
        superMap.put("smith", "949-0504");
        superMap.put("newton", "123-4567");

        Map<String, String> subMap = new TreeMap<String, String>();

        subMap.put("smith", "949-0504");
        subMap.put("marty", "206-9024");

        System.out.println("superMap: " + superMap);
        System.out.println("subMap: " + subMap);
        System.out.println();

        boolean state = false;

        if (subMap.isEmpty()) {
            state = true;
        }else {

            System.out.println(getState(subMap, superMap));
        }
    }

    public static boolean getState(Map<String, String> sub, Map<String, String> superM) {

        int count = 0;
        int size = sub.size();

        for (String name : sub.keySet()) {
            String number = sub.get(name);

            if (superM.containsKey(name) && superM.containsValue(number)) {
                count++;
            }
        }
         if(count==size){
             return true;
         }
        return false;
    }
}
