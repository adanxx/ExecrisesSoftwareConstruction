import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;
import java.util.*;
/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise16 {

    public static void main(String[] args) {

     Map<String,String> word = new TreeMap<String, String>();

      word.put("Marty","206-9024");
      word.put("Hawking","123-4567");
      word.put("smith","949-0504");
      word.put("Newton","123-4300");
      word.put("John","949-0504");     // Test the boolean statement output here

        System.out.println(is1to1(word));


    }

    public static boolean is1to1(Map<String,String> list){

        int count = 0 ;

        Map<String, String> list2 = new HashMap<String, String>();

        Set<String> allKeys = list.keySet();   // List contain all the keys of the list


        for( String key : allKeys){

            String value = list.get(key);

            if(!list2.containsValue(value)) {

                list2.put(key, value);

            }else{
                return false;
            }

        }
        return true;
    }

}
