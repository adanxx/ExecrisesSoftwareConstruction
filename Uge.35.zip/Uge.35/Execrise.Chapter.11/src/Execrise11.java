import java.util.*;


/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise11 {
    public static void main(String[] args) {


        List<Integer> list = new LinkedList<Integer>();

        list.add(1);
        list.add(4);
        list.add(7);
        list.add(9);

        Set<Integer> list11 = new TreeSet<Integer>();

        for (int n : list){
            list11.add(n);
        }

        List<Integer> list2 = new LinkedList<Integer>();

        list2.add(2);
        list2.add(4);
        list2.add(5);
        list2.add(6);
        list2.add(7);

        Set<Integer> list22 = new TreeSet<Integer>();
        for (int n : list2){
            list22.add(n);
        }

        System.out.println("List1: "+list);
        System.out.println("List2: "+list2);
        System.out.println();

        Set<Integer> newList = symmetricSetDifference(list11,list22);

        System.out.println("New List: "+newList);

    }


    public static Set<Integer> symmetricSetDifference(Set<Integer>list1, Set<Integer>list2){

        Set<Integer> num = new TreeSet<Integer>();

        Set<Integer> n1 = new HashSet<Integer>(list1);
        n1.removeAll(list2);

        for(int i : n1){
            num.add(i);
        }
        Set<Integer> n2 = new TreeSet<Integer>(list2);
        n2.removeAll(list1);

        for(int s : n2) {
            num.add(s);
        }
        return num;
    }

}
