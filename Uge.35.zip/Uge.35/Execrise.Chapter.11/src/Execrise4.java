import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise4 {

    public static void main(String[] args) {

        List<Integer> list1 = new LinkedList<Integer>();

        list1.add(-1);
        list1.add(1);
        list1.add(2);
        list1.add(4);
        list1.add(-3);
        list1.add(12);
        list1.add(8);
        list1.add(21);
        list1.add(6);
        list1.add(30);
        list1.add(15);
        list1.add(9);


        System.out.println("Size of list: " + list1.size());
        System.out.println("List: " + list1);
        Collections.sort(list1);
        System.out.println(list1);



        int number = 5;

        Iterator<Integer> num = list1.iterator();

        /*/
        while(num.hasNext()){

            int i = num.next();
            if(){

                num.remove();
            }
        }
        System.out.println(list1);
      /*/
    }
}
