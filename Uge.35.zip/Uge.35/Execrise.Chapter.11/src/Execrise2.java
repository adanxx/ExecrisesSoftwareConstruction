/**
 * Created by A.A on 8/30/2016.
 */
import com.sun.org.apache.xpath.internal.SourceTree;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Execrise2 {


    public static void main(String[] args) {

        List <Integer> list1 = new LinkedList<Integer>();

         list1.add(1);
         list1.add(2);
         list1.add(3);
         list1.add(4);
         list1.add(5);

        List <Integer> list2 = new LinkedList<Integer>();

        list2.add(7);
        list2.add(8);
        list2.add(9);
        list2.add(10);
        list2.add(11);
        list2.add(12);

        int max = list1.size() + list2.size();

        System.out.println("List1: "+list1);
        System.out.println();
        System.out.println("List2: "+list2);
        System.out.println();

        List<Integer> list3 = newList(max, list1, list2 );

        System.out.println("New List:"+list3 );
    }

    public static List<Integer> newList( int max, List<Integer> list1, List<Integer> list2){

        List<Integer> newList = new LinkedList<Integer>();

        Iterator<Integer> one = list1.iterator();
        Iterator<Integer> two = list2.iterator();

        int number =0;

        while( number < max) {

            if(one.hasNext()) {
                newList.add(one.next());
                number++;

            }if (two.hasNext()) {
                newList.add(two.next());
                number++;
            }
         }

        System.out.println("number: "+number);

      return newList;
    }
}
