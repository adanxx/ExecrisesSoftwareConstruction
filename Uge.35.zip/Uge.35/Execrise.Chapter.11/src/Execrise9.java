import java.util.LinkedList;
import java.util.*;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise9 {

    public static void main(String[] args) {

        List<Integer> list2 = new LinkedList<Integer>();

        list2.add(-5);
        list2.add(3);
        list2.add(5);
        list2.add(-1);
        list2.add(7);
        list2.add(13);
        list2.add(36);

        System.out.println("Does the list contain one Even number: " +hasEven(list2));
    }

    public static boolean hasEven(List<Integer>list){

        Iterator<Integer> num = list.iterator();

        while(num.hasNext()){

            int number = num.next();

            if(number % 2 == 0)

                return true;
        }
        return false;
    }
}
