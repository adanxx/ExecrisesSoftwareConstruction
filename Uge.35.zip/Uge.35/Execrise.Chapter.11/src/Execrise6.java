import java.util.LinkedList;
import java.util.*;

/**
 * Created by A.A on 8/30/2016.
 */
public class Execrise6 {
    public static void main(String[] args) {

        List<Integer> list1 = new LinkedList<Integer>();

        list1.add(3);
        list1.add(7);
        list1.add(3);
        list1.add(-1);
        list1.add(2);
        list1.add(3);
        list1.add(7);
        list1.add(2);
        list1.add(15);
        list1.add(15);


       int number = countUnique(list1);

        if(list1.size()==0){
            System.out.println("The list is empty");
        }else {

            System.out.println("List" + list1);
            System.out.println();
            System.out.println("List countains: "+ number + " Unique number");
        }

    }

    public static int countUnique(List<Integer> list2){

        Set<Integer> newList = new HashSet<Integer>();

        for(int n : list2){

            newList.add(n);
        }

        return newList.size();
    }


}
