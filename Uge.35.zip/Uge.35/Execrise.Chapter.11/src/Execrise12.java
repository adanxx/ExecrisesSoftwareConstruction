/**
 * Created by A.A on 8/30/2016.
 */

import java.util.*;

public class Execrise12 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        List<String> word = new LinkedList<String>();


        word.add("Abdi");       // add 3 or more of same word to test the boolean method true or fales
        word.add("Adan");       // statement.
        word.add("James");
        word.add("Ali");
        word.add("Ali");
        word.add("James");
        word.add("Abdi");
        word.add("Abdi");


        System.out.println(contains3(word));

    }

       public static boolean contains3(List<String> list) {

        Map<String, Integer> list2 = new HashMap<String, Integer>() ;

        for( String word : list) {
            if (list2.containsKey(word)) {    // word is seen before

                int count = list2.get(word);
                list2.put(word, count +1);   // the word value is increment ++
            }else {  // list does not contain the word it is add
                list2.put(word, 1);
            }
        }

           for (String word : list2.keySet()){
               int num = list2.get(word);

               if(num >= 3){
                   return true;
               }
           }

        return false;
      }
}
