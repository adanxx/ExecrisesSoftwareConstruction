import java.util.Iterator;

/**
 * Created by A.A on 9/26/2016.
 */
public class RunProgram {
    public static void main(String[] args) {

        queueClass<Integer> list = new queueClass<>();

        list.add(1);
        list.add(2);
        list.add(3);

        System.out.println("Queue: "+list.toString());
        System.out.println("Size: "+list.getSize());
        System.out.println("Peek: "+list.peek());

        while (!list.isEmpty()){
            System.out.print(list.remove()+" ");
        }
        System.out.println();
        System.out.println("After remove List: "+list.toString());

     /*/------------------------StackClass-------------------------------------

        String[] words = {"to", "be", "or","not","to","be"};

        stackClass<String> list2 = new stackClass<>();

        for(String str: words){
           list2.push(str);
        }
        System.out.println("toString:"+list2.toString());
        System.out.println("Size: "+list2.getSize());
        System.out.println("Peek: "+list2.peek());

        Iterator<String> i = list2.iterator();
        System.out.print("Iterator: ");
        while(i.hasNext()){
            String n = i.next();
            System.out.print(n+" ");
        }
        System.out.println();

        System.out.print("Pop: ");
        while(!list2.isEmpty()){
            System.out.print(list2.pop()+" ");
        }
        System.out.println();
        System.out.print("After Pop: ");
        System.out.println(list2.toString());
    /*/
    }

}
