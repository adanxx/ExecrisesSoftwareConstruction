import java.util.NoSuchElementException;

/**
 * Created by A.A on 9/27/2016.
 */
public class queueClass <E>{

    ListNode front;
    private int size;

    private class ListNode{

        private ListNode next;
        private E data;

        public ListNode( E newData, ListNode newNext) {
            this.data = newData;
            this.next = newNext;
        }
        public ListNode(E value){
            this.next = null;
            this.data = value;
        }
        public ListNode(){
            this.data = null;
            this.next = null;
        }
    }

    public queueClass(){
     front = null;
     size = 0;
 }

    public boolean isEmpty() {
        return front ==null;
    }

    public int getSize(){
        if(isEmpty()){
            throw new NoSuchElementException();
        }
        return size;
    }

    public void add(E value){

        if(isEmpty()) {
            front = new ListNode(value);
            size++;
        }else{
            ListNode current = front;
            while(current.next !=null) {
                current = current.next;
            }
            current.next = new ListNode(value);
            size++;
        }
    }

    public int peek(){
        if(isEmpty()){
            throw  new NoSuchElementException();
        }
        return (Integer)front.data;
    }

    public String toString(){

        if(isEmpty()){
            return "[]";
        }
         ListNode current = front.next;
         String resulat = "[";
        while( current !=null){
            resulat += ", "+current.data;
            current = current.next;
        }
       resulat += "]";
       return resulat;
    }

    public E remove(){

        if(isEmpty()){
            throw  new NoSuchElementException();
        }
        ListNode current = front;
        front = front.next;
        return current.data;
    }


}
