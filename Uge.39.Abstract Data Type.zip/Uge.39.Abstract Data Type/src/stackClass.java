import java.util.*;


public class stackClass<E> {

    private E[]data;
    private int size;

    public static final int totalSize = 100;

    public stackClass(){
        this.data = (E[]) new Object[totalSize];
        this.size = 0;

    }


    public void push( E value){

        data[size] = value;
        size++;
    }
    public E pop(){

        if(isEmpty()) {
            throw new NoSuchElementException();
        }
                E num = data[size];
                data[size] = null;
                size--;
                return num;
    }

    public Boolean isEmpty(){
        return size < 0;
    }
   public int peek(){
       if(isEmpty()){
           throw new NoSuchElementException();
       }
       return (Integer) data[size-1];

   }
    public int getSize(){
     return size;
    }

    public String toString(){

        if(isEmpty()){
            return "[]";
        }else{
            String result = "[" +data[0];
            for(int i = 1 ; i < size; i++){
                result += ", "+ data[i];
            }
            result +="]";
            return result;
        }

    }

}
