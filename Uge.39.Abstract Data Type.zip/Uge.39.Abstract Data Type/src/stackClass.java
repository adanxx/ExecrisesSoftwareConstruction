import java.util.*;


public class stackClass<E> {

    private E []data;
    private int size =  -1;
    public static final int totalSize = 100;

    public stackClass(){
        this.data = (E[])new Object[totalSize];
    }

    public stackClass(int capacity) {
        this.data = (E[])new Object[capacity];
    }

    public void push( E value){

        if(isFully()){
            throw new ArrayIndexOutOfBoundsException("size:"+data.length);
        }else {
            size++;
            data[size] = value;

        }
    }

    public E pop(){

        E num ;
        if(isEmpty()) {
            return null;
        }
                num = data[size];
                data[size--] = null;
                return num;
    }

    public Boolean isEmpty(){
        return size < 0;
    }

    public Object peek(){
       if(isEmpty()){
           throw new NoSuchElementException();
       }
       return data[size];
   }

    public boolean isFully(){
        return (size >= totalSize);
    }

    public int getSize(){
     return size+1;
    }

    public String toString(){

        if(isEmpty()){
            return "[]";
        }else{
            String result = "[" +data[0];
            for(int i = 1 ; i < getSize(); i++){
                result += ", "+ data[i];
            }
            result +="]";
            return result;
        }

    }


    public Iterator <E> iterator(){
        return new stackIterator();
    }


    private class stackIterator implements Iterator <E> {

        private int position = 0;

        @Override
        public boolean hasNext() {
            return position < getSize();
        }

        @Override
        public E next() {

            if(!hasNext()){
                throw new NoSuchElementException();
            }
            E resultat = data[position];
            position++;
            return resultat;
        }

        @Override
        public void remove() {
            System.out.println("Not being used");
        }
    }



}
