import java.util.*;


public class stackClass<E> {

    private Object []data;
    private int size =  -1;
    public static final int totalSize = 100;

    public stackClass(){
        this.data = new Object[totalSize];
    }
    public stackClass(int capacity){
        this.data = new Object[capacity];
    }

    public void push( Object value){

        if(isFully()){
            throw new ArrayIndexOutOfBoundsException("size:"+data.length);
        }else {
            size++;
            data[size] = value;

        }
    }

    public Object pop(){

        Object num ;
        if(isEmpty()) {
            return "Stack is empty";
        }
                num = data[size];
                data[size--] = null;
                return num;
    }

    public Boolean isEmpty(){
        return size < 0;
    }

    public Object peek(){
       if(isEmpty()){
           throw new NoSuchElementException();
       }
       return data[size];
   }

    public boolean isFully(){
        return (size >= totalSize);
    }

    public int getSize(){
     return size+1;
    }

    public String toString(){

        if(isEmpty()){
            return "[]";
        }else{
            String result = "[" +data[0];
            for(int i = 1 ; i < getSize(); i++){
                result += ", "+ data[i];
            }
            result +="]";
            return result;
        }

    }

}
