import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by A.A on 9/27/2016.
 */
public class stackClassTest {

    stackClass<Integer> list = new stackClass<>();

    @Test
    public void push() throws Exception {
        list.push(1);
        list.push(2);
        list.push(3);

        assertEquals(3,list.getSize());

    }

    @Test
    public void pop() throws Exception {
        list.push(1);
        list.push(2);
        list.push(3);

        list.pop();
        assertEquals(2,list.getSize());

    }

    @Test
    public void isEmpty() throws Exception {
           list.push(1);
        assertFalse(list.isEmpty());
    }

    @Test
    public void peek() throws Exception {
        list.push(1);
        list.push(2);
        list.push(3);

        assertEquals(3, list.peek());
    }

    @Test
    public void getSize() throws Exception {
        list.push(1);
        list.push(2);
        list.push(3);

        assertEquals(3, list.getSize());


    }

}