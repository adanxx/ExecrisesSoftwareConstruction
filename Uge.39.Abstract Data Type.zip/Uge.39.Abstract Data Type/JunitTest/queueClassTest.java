import org.junit.Test;

import java.util.NoSuchElementException;

import static org.junit.Assert.*;

/**
 * Created by A.A on 9/27/2016.
 */
public class queueClassTest {

    queueClass<Integer> list = new queueClass<>();


    @Test (expected = NoSuchElementException.class)
    public void isEmpty() throws Exception {
        assertEquals(0,list.getSize());

    }
    @Test
    public void getSize() throws Exception {
        list.add(1);
        list.add(2);
        list.add(3);

        assertEquals(3,list.getSize());

    }
    @Test
    public void add() throws Exception {
        list.add(3);
        list.add(2);
        list.add(1);

        assertEquals(3,list.peek());

    }
    @Test
    public void peek() throws Exception {
        list.add(1);
        list.add(2);
        list.add(3);

        assertEquals(1,list.peek());

    }
    @Test
    public void remove() throws Exception {
        list.add(1);
        list.add(2);
        list.add(3);

        list.remove();
        assertEquals(2,list.peek());


    }

}