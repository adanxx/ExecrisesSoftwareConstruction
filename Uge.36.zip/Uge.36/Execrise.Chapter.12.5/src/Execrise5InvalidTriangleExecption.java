/**
 * Created by A.A on 9/6/2016.
 */
import java.lang.*;
public class Execrise5InvalidTriangleExecption extends Exception {

    private double side1;
    private double side2;
    private double side3;

    public Execrise5InvalidTriangleExecption(double side1, double side2, double side3){

            super("Invalide parameter in one of the side"+side1+", "+side2+", "+side3);

        //this.side1 = side1;
        //this.side2 = side2;
        //this.side3 = side3;
    }
    public String toString(){
        return "Triangle: side1= " +side1+" side2 = "+side2+" side3 = "+side3;
    }
}
