/**
 * Created by A.A on 9/6/2016.
 */
import java.lang.*;
public class Execrise5Main {

    public static void main(String[] args) throws Execrise5InvalidTriangleExecption {

        try {

            Execrise5Class Tri1 = new Execrise5Class(4, 3, 4);
            Execrise5Class Tri2 = new Execrise5Class(3, 3, 3);
            Execrise5Class Tri3 = new Execrise5Class(5, 8, 6);

            System.out.printf("Tri1: %2.2f\n",Tri1.getArea());
            System.out.println();
            System.out.printf("Tri2: %2.2f\n",Tri2.getArea());
            System.out.println();
            System.out.printf("Tri3: %2.2f\n",Tri3.getArea());


        }catch (Execrise5InvalidTriangleExecption ex){

            System.out.println(ex);

        }

    }
}
