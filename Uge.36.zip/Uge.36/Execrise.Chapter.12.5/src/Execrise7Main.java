import java.util.Scanner;

/**
 * Created by A.A on 9/13/2016.
 */
public class Execrise7Main {

    public static void main(String[] args) throws NumberFormatException {

        Scanner input = new Scanner(System.in);
        boolean state = true;

        do {

            try {
                System.out.print("Enter a Binary of  number: ");
                String bin = input.next();

                int bit = Integer.parseInt(bin, 2);
                System.out.println("Binary value: "+bit);
                input.nextLine();
                state = false;
            } catch (java.lang.NumberFormatException ex) {
                System.out.println(ex);
                input.nextLine();
            }
        } while (state);
    }
}
