import java.util.Scanner;

/**
 * Created by A.A on 9/7/2016.
 */
import java.util.*;
import java.lang.*;
public class Execrise8Main {
    public static void main(String[] args) throws binaryFormatException {

      Scanner input = new Scanner(System.in);

        System.out.print("Enter a Binary value: ");
        String bin = input.next();

        try{
            binaryValues bit = new binaryValues(bin);
            System.out.println(bit.getBinary());
        }catch(java.lang.NumberFormatException ex){
            System.out.println(ex);
        }
    }
}

class binaryValues{
    private String binary;

    public binaryValues(String newBinary) throws binaryFormatException{
        setBinary(newBinary);
    }

    public void setBinary(String newBinary)throws binaryFormatException{

        int count = 0;
         for(int i = 0 ; i < newBinary.length(); i++) {
             if (Character.isDigit(newBinary.charAt(i))){
                 count++;
                 if(newBinary.length()==count){
                     this.binary = newBinary;
                 }
             }else{
                 throw new binaryFormatException(newBinary);
             }
         }
    }
    public String getBinary() {
        return "binary: "+Integer.parseInt(binary, 2);
    }
}
