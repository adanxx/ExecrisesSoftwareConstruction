/**
 * Created by A.A on 9/6/2016.
 */
import java.lang.*;

public class Execrise5Class {

    private double side1;
    private double side2;
    private double side3;

    public Execrise5Class() throws Execrise5InvalidTriangleExecption {
        this(12.0,23.0,23.0);
    }

    public Execrise5Class(double newSide1, double newSide2, double newSide3) throws Execrise5InvalidTriangleExecption {

        try {
            setSideOfTriangle(newSide1, newSide2, newSide3);
        } catch (Execrise5InvalidTriangleExecption ex) {
            System.out.println("Illegal Triangle: Side1: "+ side1 + ", side2: "+ side2 + ", Side3: "+ side3);
        }
    }

    public  void setSideOfTriangle(double newSide1,double newSide2, double newSide3) throws Execrise5InvalidTriangleExecption {

        if (newSide1 + newSide2> newSide3 ){
            if(newSide1+newSide3 > newSide2)
                if(newSide2 + newSide3 >newSide1)
            this.side1 = newSide1;
            this.side2 = newSide2;
            this.side3 = newSide3;
    }else {
            throw new Execrise5InvalidTriangleExecption(side1,side2,side3);
        }
    }

    public double getArea(){
        double s = (side1 + side2 +side3)/2.0;
        return Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
    }
    public double getPerimeter(){
        return side1+side2+side3;
    }
    public String toString(){
        return "Triangle: side1= " +side1+" side2 = "+side2+" side3 = "+side3;
    }

   public double getSide1(){
       return side1;
   }
    public double getSide2(){
        return side2;
    }
    public double getSide3(){
        return side3;
    }
}
