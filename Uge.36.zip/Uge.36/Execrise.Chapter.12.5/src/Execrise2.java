
 //Created by A.A on 9/6/2016.

 import java.util.*;
import java.lang.*;

 public class Execrise2 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int sum = 0;
        boolean state = true;

        do {

            try {

                System.out.println("Enter two integer and prompter will return the sum: ");
                int one = input.nextInt();
                input.nextLine();
                int two = input.nextInt();
                sum = one + two;
                System.out.println("The Sum of the input = " + sum);
                state = false;

            } catch (InputMismatchException ex) {
                System.out.println("Incorrect input integer is required");
                input.nextLine();
            }
        }while (state);
    }
}
