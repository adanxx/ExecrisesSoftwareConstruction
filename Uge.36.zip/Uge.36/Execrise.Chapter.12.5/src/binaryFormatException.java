/**
 * Created by A.A on 9/13/2016.
 */
public class binaryFormatException extends Exception {
    private String binary;

    public binaryFormatException(String newbBinary){
        super("invalide input: "+newbBinary);
        this.binary = newbBinary;
    }

    public String getBinary() {
        return binary;
    }
}
