/**
 * Created by A.A on 9/6/2016.
 */
public class Execrise4Class {

    private double annualInterestRate;
    private int numberOfYears;
    private double loanAmount;
    private java.util.Date loanDate;

    public Execrise4Class(){
        this(2.5,1,1000);
    }

    public Execrise4Class(double newAnnualInterestRate,int newNumberOfYears,double newLoanAmount){

        setAnnualInterestRate(newAnnualInterestRate);
        setnNumberOfYears(newNumberOfYears);
        setLoanAmount(newLoanAmount);

        loanDate = new java.util.Date();
    }
    public double getAnnualInterestRate(){
        return annualInterestRate;
    }
    public int getNumberOfYears(){
        return numberOfYears;
    }
    public double getLoanAmount(){
        return loanAmount;
    }

    public void setAnnualInterestRate(double annualInterestRate)throws IllegalArgumentException{
        if( annualInterestRate > 0)
        this.annualInterestRate = annualInterestRate;
        else
            throw new IllegalArgumentException("annualInterestRate can't be negative or Zero");
    }
    public void setnNumberOfYears(int numberOfYears)throws  IllegalArgumentException{

        if( numberOfYears > 0)
            this.numberOfYears = numberOfYears;
        else
            throw new IllegalArgumentException("numberOfYears can't be negative or Zero");
    }
   public void setLoanAmount(double loanAmount)throws IllegalArgumentException{

       if( loanAmount > 0)
           this.loanAmount= loanAmount;
       else
           throw new IllegalArgumentException("loanAmount can't be negative or Zero");

    }
    //Return the LoanDate
    public java.util.Date getLoanDate(){
        return  loanDate;
    }
    //Find monthly Paymen
    public double getMonthlyPayment(){
        double monthlyInterestRate = annualInterestRate/1200;
        double monthlyPayment = loanAmount*monthlyInterestRate / (1-(1/Math.pow
                (1 + monthlyInterestRate, numberOfYears*12)));
        return monthlyPayment;
    }
    //Find the Payment
    public double getTotalPayment(){
        double totalPayment = getMonthlyPayment()*numberOfYears*12;
        return totalPayment;
    }
}
