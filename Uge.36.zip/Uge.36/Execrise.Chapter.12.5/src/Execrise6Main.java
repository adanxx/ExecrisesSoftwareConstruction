/**
 * Created by A.A on 9/6/2016.
 */
import java.lang.*;
import java.util.*;

public class Execrise6Main {
    public static void main(String[] args) throws NumberFormatException {

        Scanner input = new Scanner(System.in);
        try {
            System.out.print("Enter a hex number: ");
            String hex = input.nextLine();
            System.out.println("The Decimal value for hex number: " + hexToDecimal(hex.toUpperCase()));
        } catch (java.lang.NumberFormatException ex) {
            System.out.println(ex);
        }
    }
    public static int hexToDecimal(String hex) throws NumberFormatException {

        try{
            int decimalValue = 0;
            for (int i = 0; i < hex.length(); i++) {
                char hexChar = hex.charAt(i);
                decimalValue = decimalValue * 16 + hexTCharToDecimal(hexChar);
            }
            return decimalValue;
        }catch(NumberFormatException ex){
            throw new NumberFormatException("Invalid Exception hexToDecimal");
        }
    }

    public static int hexTCharToDecimal(char ch) throws NumberFormatException{

        if(ch > 'F' || ch < '0' )          // determine the exception handling parameter
            throw new NumberFormatException();
        else if( ch >= 'A'&& ch <='F')
            return  10 + ch -'A';
        else
            return  ch - '0';
    }
}
