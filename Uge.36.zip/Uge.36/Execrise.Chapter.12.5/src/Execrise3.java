/**
 * Created by A.A on 9/6/2016.
 */
import java.util.*;

public class Execrise3 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        int [] number = new int [100];

        for( int i = 0 ; i < number.length; i++){
            number[i]= rand.nextInt(70)+i;
        }try {

            System.out.print("The Array contains "+number.length+" input index number 0-99: ");
            int num = input.nextInt();

            System.out.println("number in index is: "+number[num]);
        }catch (ArrayIndexOutOfBoundsException ex){
            System.out.println("index input: "+ex.getMessage() +" is out of Bound");
        }
    }
}
