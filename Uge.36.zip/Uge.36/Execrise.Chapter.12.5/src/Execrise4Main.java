import java.time.Month;

/**
 * Created by A.A on 9/6/2016.
 */
import java.lang.*;
public class Execrise4Main {
    public static void main(String[] args)  {

        Execrise4Class n1 = new Execrise4Class(12.5,5,6.5);
        Execrise4Class n2 = new Execrise4Class(10.5,2,2.5);
        Execrise4Class n3 = new Execrise4Class(7.5,4,6.5);  //Change the parameter to number negativ
                                                            // or Zero to throw an Execption handling

            try {

                System.out.println(n1.getLoanDate());
                System.out.println(n2.getLoanDate());
                System.out.println(n3.getLoanDate());

            } catch (IllegalArgumentException ex){
                System.out.println(ex);
            }

    }

}

