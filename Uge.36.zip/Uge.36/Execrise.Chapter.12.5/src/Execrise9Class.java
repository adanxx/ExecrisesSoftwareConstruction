import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

/**
 * Created by A.A on 9/8/2016.
 */
public class Execrise9Class {
    public static void main(String[] args) throws hexFormatException{

        try {
            Hex2Dec num = new Hex2Dec("ABC8");
            System.out.println(num.getHex());

        }catch (java.lang.NumberFormatException ex){
            System.out.println(ex);
        }

    }
}

class Hex2Dec{

    private String hex;

    public Hex2Dec(String newHex)throws hexFormatException{
        setHex(newHex);
    }

    public void setHex(String newhex) throws hexFormatException {

        int decimalValue = 0;
        try{
            for (int i = 0; i < newhex.length(); i++) {
                char hexChar = newhex.charAt(i);
                decimalValue = decimalValue * 16 + hexToCharToDecimal(hexChar);
            }
            hex = "hex: "+ decimalValue;
        }catch(hexFormatException ex){
            throw new hexFormatException(newhex);
        }
    }

    private int hexToCharToDecimal(char ch)throws hexFormatException {

        if(ch > 'F' || ch < '0' )          // determine the exception handling parameter
            throw new hexFormatException("Invalid Exception HexToChar");
        else if( ch >= 'A'&& ch <='F')
            return  10 + ch -'A';
        else
            return  ch - '0';
    }

    public String getHex() {
        return hex;
    }
}