/**
 * Created by A.A on 9/13/2016.
 */
public class Execrises10Main {
}
