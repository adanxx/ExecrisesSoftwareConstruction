/**
 * Created by A.A on 9/6/2016.
 */
import java.lang.*;
public class Execrise1 {

    public static void main(String[] args) {
        //Check the number of string passed;


        String[] numbers = {"seven", "2"};
        String[] opertor = {"+", "-", "/", "*"};

        try {

            // The result of the operation;
            int result = 0;

            for (int s = 0; s < opertor.length; s++) {
                //Determine the operator;
                switch (opertor[s]) {

                    case "+":
                        result = Integer.parseInt(numbers[0]) + Integer.parseInt(numbers[1]);
                        break;
                    case "-":
                        result = Integer.parseInt(numbers[0]) - Integer.parseInt(numbers[1]);
                        break;

                    case "/":
                        result = Integer.parseInt(numbers[0]) / Integer.parseInt(numbers[1]);
                        break;

                }
                System.out.println(numbers[0] + " " + opertor[s] + " " + numbers[1] + " = " + result);
            }
        }catch (NumberFormatException ex){
            System.out.println("Invalid input: "+ex.getMessage() + " in the Array");

        }
    }
}
