/**
 * Created by A.A on 9/13/2016.
 */
public class hexFormatException extends Exception {
    private String hex;

    public hexFormatException(String newHex){
        super("Invalid input: "+newHex);
        this.hex = newHex;
    }

    public String getHex() {
        return hex;
    }
}
