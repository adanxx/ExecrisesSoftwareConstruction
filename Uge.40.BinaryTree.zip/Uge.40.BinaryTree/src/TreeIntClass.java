import java.util.*;

/**
 * Created by A.A on 10/4/2016.
 */
public class TreeIntClass {

    private IntTreeNode overallRoot;

    //post: constructs and empty tree
    public TreeIntClass() {
        overallRoot = null;
    }

   //post: constructs a sequential tree with given number of nodes
    public TreeIntClass(int max) {
        if (max < 0) {
            throw new IllegalArgumentException("max " + max);
        }
        overallRoot = buildTree(1, max);
    }

    //post: returns a sequential tree with n as its root, unless n is greater than max, in which
    //      case returns an empty tree, if max < 0 it throw and IllegalArgumentException
    private IntTreeNode buildTree(int n, int max) {
        if (n > max){
            return null;
    }else{
        return new IntTreeNode(n, buildTree(2*n, max),buildTree(2*n+1,max));
       }
   }

    //post: value are added to overall tree so as to preserve the binary search tree property
    public void add(int value){
        overallRoot = add(overallRoot, value);
    }

    //post: value is added o given tree so as to preserve the binary
    //      search tree property:
    private IntTreeNode add(IntTreeNode root, int value){
        if(root == null){
            root = new IntTreeNode(value);
        }else if(value <= root.data){
            root.left = add(root.left,value);
        }else {
            root.right = add(root.right, value);
        }
            return root;
    }

    //post: return true iv overall ree contains value
    public boolean contains (int value){
        return contains(overallRoot, value);
    }
    //post: return true if given tree contains value
    private boolean contains(IntTreeNode root,int value){
        if(root==null){
            return false;
        }else if (root.data == value){
            return true;
        }else if(value < root.data){
            return contains(root.left,value);
        }else{
            return contains(root.right,value);
        }
    }

    //post: prints the tree contents using an inorder traversal
     public void print(){
         printInorder(overallRoot);
         System.out.println();
     }
    //post: prints contents of the tree with given root using and
    //      inorder traversal
     private void printInorder(IntTreeNode root){

              if(root !=null) {
                  printInorder(root.left);
                  System.out.print(root.data + " ");
                  printInorder(root.right);
              }

     }

    // post: prints the tree contents, one per line, following an
    // inorder traversal and using indentation to indicate node
    // depth: prints right to left showing the level of the tree
    // when output is rotated
     public void printSideways(){
          printSideways(overallRoot,0);
     }
      private void printSideways(IntTreeNode root, int level){
          if(root != null){
              printSideways(root.right, level+1);
              for( int i =0 ;  i < level; i++){
                  System.out.print("    ");
              }
              System.out.println(root.data);
              printSideways(root.left,level +1);
          }
      }

    // private class for storing a single node of binary tree of ints:
    private class IntTreeNode {
        public int data;
        public IntTreeNode left;
        public IntTreeNode right;

        //constructs a leaf node with given data
        public IntTreeNode(int data) {
            this(data, null, null);
        }

        //constructs a branch node with given data, left subtree right subtree
          public IntTreeNode(int data, IntTreeNode right, IntTreeNode left) {
              this.data = data;
              this.left = left;
              this.right = right;
          }
        public int getData() {
            return data;
        }
    }

    // post: return the number of levels in the tree:
    public int countLevels(){
        return  countLevels(overallRoot);
    }
    private int countLevels(IntTreeNode root){
        if(root == null){
            return 0;
        }
        return 1+Math.max(countLevels(root.right), countLevels(root.left));
    }

//------------------------------------Exercises.--------------------------------------

//Exercises.1.Done
    // post: return the number of LeftNodes in the tree:
    public int countLeftNodes(){
        return  countLevels(overallRoot);
    }
    private int countLeftNodes(IntTreeNode root) {

        if (root == null) {
            return 0;
        } else if (root.left == null) {
            return countLeftNodes(root.right);
        } else {
        return 1 + countLeftNodes(root.left) + countLeftNodes(root.right);
      }
    }

//Exercises.2.Done:
    // post: return the number of empty branches in the tree:
    public int countEmpty(){
        return countEmpty(overallRoot);
    }
    private int countEmpty(IntTreeNode root) {

        if(root == null){
            return 1;
        }else{
            return countEmpty(root.left) + countEmpty(root.right);
        }

    }

//Exercises.3.Done
    public int depthSum (){
         return depthSum(overallRoot, 1);
     }
    private int depthSum(IntTreeNode root, int n){

          if(root == null){
              return 0;
          }else{
              return root.data*n + depthSum(root.left,n+1) + depthSum(root.right, n+1);
          }
      }

//Exercises.4.Done
    public int countEvenBranches(){
        return countEvenBranches(overallRoot);
    }
    private int countEvenBranches(IntTreeNode root) {

       if(root ==null){
           return 0;
       }else if(root.right ==null && root.left ==null ){
           return 0;
       }else if(root.data % 2 !=0){
           return countEvenBranches(root.left)+countEvenBranches(root.right);
       }else{
        return 1 + countEvenBranches(root.right)+countEvenBranches(root.right);
       }
    }

//Exercises.5.Done

    public void printLevels(int max){

        printLevels(overallRoot,0, max);
    }
    private void printLevels(IntTreeNode root, int currentlevel, int max){

        if(root == null || currentlevel > max){
            return ;

        } if(currentlevel == max) {
            System.out.println(root.data + " ");
        }
            printLevels(root.right,currentlevel+1,max);
            printLevels(root.left, currentlevel+1,max);

    }

//Exercises.6.Done
    public void printLeavesR(){
        if(overallRoot == null){
            System.out.println("Tree is empty");
        }else {
            printLeavesR(overallRoot);
        }
    }
    private void printLeavesR(IntTreeNode root){
         if(root != null) {

           if(root.right ==null && root.left == null){
               System.out.print(" "+root.data);
           }else{
               printLeavesR(root.right);
               printLeavesR(root.left);
           }
         }
    }

//Exercises.7.Done
    public boolean isFull(){
        return isFull(overallRoot);
    }
    private boolean isFull(IntTreeNode root) {

        if (root!=null)
        {
            if(root.right == null && root.left == null)
            {
                return true;
            }
            if ((root.right != null && root.left != null))
            {
                return isFull(root.right)&& isFull(root.left);
            }
        }
        return false;

    }

//Exercises.8.Done

    public String toString(){
        return toString(overallRoot);
    }
    private String toString(IntTreeNode root){

        String s = "";
        if(root == null) {
            return "empty";
        }
        s += "("+root.data+",";
        s +=  toString(root.left) + "," + toString(root.right) ;
        s +=")";
        return s;

    }

//Exercises.9.Not Done

    public boolean equals(IntTreeNode root2){
        return equals(overallRoot, root2);
    }
       private boolean equals(IntTreeNode root, IntTreeNode root2){

           if(root == null && root2 ==null){
               return  true;             //root == null && root2 == null;
           }else if (root.data == root2.data){
               return equals(root.right, root2.right)&& equals(root.left, root2.left);
           }else{
               return false;
           }

       }

//Exercises.10.Done

    public void doublePostive(){
        doublePostive(overallRoot);
    }
    private void doublePostive(IntTreeNode root){

        if(root != null) {
            if (root.data > 0) {
                root.data = root.data * 2;
            }
            doublePostive(root.right);
            doublePostive(root.left);
        }
    }

}
