/**
 * Created by A.A on 10/8/2016.
 */
public class Exercises8 {
    public static void main(String[] args) {

        TreeIntClass tree = new TreeIntClass(4);

        tree.printSideways();
        System.out.println();

        System.out.println(tree.toString());

    }
}
