/**
 * Created by A.A on 10/9/2016.
 */
public class Exercises10 {
    public static void main(String[] args) {

        TreeIntClass tree1 = new TreeIntClass();

        tree1.add(3);
        tree1.add(2);
        tree1.add(1);           //add negative value to test doublePostive Method
        tree1.add(4);
        tree1.add(5);
        tree1.add(4);
        tree1.printSideways();
        System.out.println();
        tree1.doublePostive();
        tree1.printSideways();


    }
}
