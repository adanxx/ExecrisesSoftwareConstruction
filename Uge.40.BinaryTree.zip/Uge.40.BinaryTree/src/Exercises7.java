/**
 * Created by A.A on 10/8/2016.
 */
public class Exercises7 {

    public static void main(String[] args) {

        TreeIntClass tree1 = new TreeIntClass(3);
        TreeIntClass tree2 = new TreeIntClass(4);
        tree1.printSideways();
        System.out.println();
        tree2.printSideways();
        System.out.println();

        System.out.println("Is Tree1 full: "+tree1.isFull());
        System.out.println("Is Tree2 full: "+tree2.isFull());


    }
}
