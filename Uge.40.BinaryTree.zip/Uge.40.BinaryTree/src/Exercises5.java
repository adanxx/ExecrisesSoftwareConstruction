/**
 * Created by A.A on 10/8/2016.
 */
public class Exercises5 {
    public static void main(String[] args) {

        TreeIntClass tree1 = new TreeIntClass();

        tree1.add(2);
        tree1.add(8);
        tree1.add(1);
        tree1.add(0);
        tree1.add(6);
        tree1.add(9);
        tree1.add(4);
        //tree1.printSideways();
        System.out.println();
        tree1.printLevels(2);

    }
}
