
import java.util.*;
public class Exercises9 {
    public static void main(String[] args) {

        TreeIntClass tree1 = new TreeIntClass();

        //tree1.add(3);
        //tree1.add(2);
        //tree1.add(5);
        //tree1.add(4);

        TreeIntClass tree2 = new TreeIntClass();

        //tree2.add(3);
        //tree2.add(2);
        //tree2.add(5);
        //tree2.add(4);
        //tree2.add(5);

        System.out.println(tree1.equals(tree2));

    }
}
