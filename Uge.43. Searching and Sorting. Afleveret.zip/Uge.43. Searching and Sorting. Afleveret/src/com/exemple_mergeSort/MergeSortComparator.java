package com.exemple_mergeSort;

import java.util.Arrays;

/**
 * Created by A.A on 11/7/2016.
 */
public class MergeSortComparator {

    /** The method for sorting the numbers */
    public static void mergeSort(Integer [] list) {

        if (list.length > 1) {
            // Merge sort the first half
            Integer [] firstHalf =  new Integer[list.length / 2];

            System.arraycopy(list, 0, firstHalf, 0, list.length / 2);
            mergeSort(firstHalf);

            // Merge sort the second half
            int secondHalfLength = list.length - list.length / 2;
            Integer [] secondHalf =  new Integer[secondHalfLength];

            System.arraycopy(list, list.length / 2, secondHalf, 0, secondHalfLength);
            mergeSort(secondHalf);


            // Merge firstHalf with secondHalf into list
            merge(firstHalf, secondHalf, list );
        }
    }

    /** Merge two sorted lists */
    public static void merge(Integer [] list1, Integer [] list2, Integer [] temp  ) {
        int current1 = 0; // Current index in list1
        int current2 = 0; // Current index in list2
        int current3 = 0; // Current index in temp

        Arrays.sort( list1, new newComparator2());
        Arrays.sort(list2, new newComparator2());

        Integer[] listF = list1;
        Integer[] listS = list2;

        System.out.print("First: "+Arrays.toString(listF));
        System.out.println();
        System.out.print("Second: "+Arrays.toString(listS));
        System.out.println();

        while (current1 < list1.length) {
            temp[current3++] = list1[current1++];
        }
        while (current2 < list2.length) {
            temp[current3++] = list2[current2++];
        }
        Arrays.sort(temp, new newComparator2());

    }

    /** A test method */
    public static void main(String[] args) {
        Integer[] list = {2, 3, 5, 6, 1, -2, 3, 14, 12};
        mergeSort(list);


        System.out.println("Final: " + Arrays.toString(list));

    }

}
