package com.exemple_bubblesort;

import java.util.*;

public class BubbleSortComparator {


    /** A test method */
    public static void main(String[] args) {
        Integer [] list = {2, 3, 2, 5, 6, 1, -2, 3, 14, 12};


        Arrays.sort(list, new newComparator());

        for(Integer s : list){
            System.out.print(s+" ");
        }
    }


}
