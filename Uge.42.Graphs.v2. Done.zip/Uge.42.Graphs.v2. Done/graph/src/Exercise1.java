import com.exemple_GraphTest.AbstractGraph;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


public class Exercise1 {

    public static void main(String[] args) throws FileNotFoundException {


        String fileName = "C:\\Users\\A.A\\Desktop\\KEA\\1.Kea.Semester\\Semester.2\\1.2.SoftwareC\\" +
                "1.Exercises and Assigment\\Uge.42.Graphs.v2. Done\\graph\\src\\Graph1.txt";

        Scanner file = new Scanner(new File(fileName));
        String amountOfVertices = file.nextLine();
        System.out.println("Number of vertices: " + amountOfVertices);

        List<AbstractGraph.Edge> list = new ArrayList<>();

        while (file.hasNextLine()) {
            String num = file.nextLine();
            List<String> data = Arrays.asList(num.split("\\s+"));
            for (int i = 1; i < data.size(); i++) {
                AbstractGraph.Edge e = new AbstractGraph.Edge(Integer.parseInt(data.get(0)), Integer.parseInt(data.get(i)));
                list.add(e);
            }
        }

        UnweightedGraph pin = new UnweightedGraph(list, Integer.parseInt(amountOfVertices));
        pin.printEdges();

        AbstractGraph.Tree tree = pin.dfs(Integer.parseInt(amountOfVertices) - 1);
        if (tree.getNumberOfVerticesFound() == Integer.parseInt(amountOfVertices)) {
            System.out.println();
            System.out.println("The Graph is connected:");
        }else{
            System.out.println();
            System.out.println("The Graph is not connected:");
        }
    }

}
