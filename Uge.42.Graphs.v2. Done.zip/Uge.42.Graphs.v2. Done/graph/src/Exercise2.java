import com.exemple_GraphTest.AbstractGraph;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Exercise2 {

    public static void main(String[] args) throws FileNotFoundException {

        String fileName = "C:\\Users\\A.A\\Desktop\\KEA\\1.Kea.Semester\\Semester.2\\" +
                "1.2.SoftwareC\\1.Exercises and Assigment\\Uge.42.Graphs.v2. Done\\graph\\src\\Graph2.txt";


        Scanner readFile2 = new Scanner(new File(fileName));
        String amountOfVertices = readFile2.nextLine();
        System.out.println("Number of vertices: " + amountOfVertices);

        List<AbstractGraph.Edge> list2 = new ArrayList<>();

        while (readFile2.hasNextLine()) {
            String s = readFile2.nextLine();
            List<String> tokens2 = Arrays.asList(s.split("\\s+"));
            for (int i = 1; i < tokens2.size(); i++) {
                AbstractGraph.Edge edge2 = new AbstractGraph.Edge(Integer.parseInt(tokens2.get(0)), Integer.parseInt(tokens2.get(i)));
                list2.add(edge2);
            }
        }

        // create graph
        UnweightedGraph g = new UnweightedGraph(list2, Integer.parseInt(amountOfVertices));
        g.printEdges();

        AbstractGraph.Tree tree = g.dfs(Integer.parseInt(amountOfVertices) - 1);
        if (tree.getNumberOfVerticesFound() == Integer.parseInt(amountOfVertices)) {
            System.out.println("The graph is connected");
        }else{
            System.out.println();
            System.out.println("The graph is not connected");
        }
    }

}
